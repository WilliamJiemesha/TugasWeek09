from app import app ## import app dari package app yang kita buat

if __name__ == "__main__":
    app.run()

#Ingat:
#1. Jalankan '. venv/bin/activate'
#2. 'python -m venv venv'
#3. 'export FLASK_APP=server.py'
#4. 'flask run'

#https://flask.palletsprojects.com/en/1.1.x/tutorial/templates/