from flask import Flask, render_template, url_for, request
from app import app
from app.models.user import User ## import kelas User dari model

# @app.route('/', methods = ['GET'])
# def index():
# 	user =  User() ## membuat objek dari kelas user
# 	nama = user.getName() ## memanggil method untuk mengambil nama
# 	return render_template('index09.html', nama=nama)

@app.route('/')
def index():	
	return render_template('auth/index09.html')

@app.route('/register')
def registerpage():
	return render_template('auth/register09.html')
	
@app.route('/login')
def loginpage():
	return render_template('auth/login09.html')